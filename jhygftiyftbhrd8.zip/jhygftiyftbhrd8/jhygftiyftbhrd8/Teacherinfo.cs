﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jhygftiyftbhrd8
{
    class Teacherinfo : Peoplenames
    {
        private string rank;
        private string salary;
        private string status;

        private string feedback;

        public Teacherinfo(double id, string fname, string lname, string rank, string salary, string status) : base(id, fname, lname)
        {
            this.Rank = rank;
            this.Salary = salary;
            this.Status = status;
        }

        public string Rank
        {
            get
            {
                return rank;
            }
            set
            {
                rank = value;
            }

        }

        public string Salary
        {
            get
            {
                return salary;
            }
            set
            {
                salary = value;

            }

        }

        public string Status
        {
            get
            {
                return status;
            }
            set
            {
                status = value;

            }

        }

        public override string getnames()
        {
            return base.getnames() + $"\nStatus: {status}\n" + $"Rank: {rank}\nSalary: ${salary}";
        }

    }
}

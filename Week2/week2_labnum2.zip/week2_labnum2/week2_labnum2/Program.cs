﻿
// ADAM M MONIZ                 JAN 18,2020                         WEEK 2 / LAB 2 
// THIS PROGRAM WILL ALLOW A USER TO INPUT 5 GRADES FOR MULTI STUDENTS .. THIS PROGRAM WILL DEPEND ON HOW MANY GRADES ARE BEING ENTERED FOR A NUMBER OF STUDENTS....
// AT THE END OF THIS PROGRAM IT WILL DISPLAY EACH STUDENTS GRADE AVERAGE ALONG WITH A ASSIGNED LETTER GRADE AND ALSO THE CLASSES OVERRALL GRADE....



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week2_labnum2
{
    class Program
    {
        static void Main(string[] args)
        {

            //------------------------------------------------------------> Dec Variables ! (BELOW)
            int studentHeadCnt, gradeLabel = 1, studentLabel = 1;

            Decimal num1dl, num2dl, num3dl, num4dl, num5dl, studentSum, classSum = 0, classAvgstr = 0, classAvg = 0;
            Decimal  lab1Avg = 0, lab2Avg = 0, lab3Avg = 0, lab4Avg = 0, lab5Avg = 0;
           
            //------------------------------------------------------------> Dec Variables ! (ABOVE)













            //------------------------------------------------------------< BASE PROGRAM START (BELOW)

            Console.WriteLine("Welcome To The Student Grade Avg Cal!");
            Console.Write("\nHow Many Students Are You Entering Grades For?: "); // Fetching the amount of students there will be grades put in for....
            studentHeadCnt = Convert.ToInt32(Console.ReadLine());




            //------------------------------------------------------------> Creating Lists/ Arrays (BELOW)

            Decimal[] studentGradeArray = new Decimal[studentHeadCnt];// Array for 5 lab grades to be entered in 

            //------------------------------------------------------------> Creating Lists/ Arrays (ABOVE)



            Console.Clear();//clear console




            String[] studentName = new string[studentHeadCnt];//------------------------------->student name array
            String[] letterGrade = new string[studentHeadCnt];//------------------------------->letter grade array
            
            Decimal lab1 = 0, lab2 = 0, lab3 = 0, lab4 = 0, lab5 = 0;//------------------------> declaring variables


            for (int x = 0; x < studentHeadCnt; x++) { //start of the first for loop



                Console.Write("-----------------------------------------");
                Console.Write($"\nPlease Enter #{studentLabel++} Student's First Name: ");// Student Name input 
                studentName[x] = Console.ReadLine();

                //----------------------------------------------------------------------> Grade input & calculations
                Console.Write($"\nEnter Grade #{gradeLabel ++}: ");
                num1dl = Convert.ToDecimal(Console.ReadLine());
                lab1 = (lab1 + num1dl);

                Console.Write($"\nEnter Grade #{gradeLabel ++}: ");
                num2dl = Convert.ToDecimal(Console.ReadLine());
                lab2 = (lab2 + num2dl);

                Console.Write($"\nEnter Grade #{gradeLabel ++}: ");
                num3dl = Convert.ToDecimal(Console.ReadLine());
                lab3 = (lab3 + num3dl);

                Console.Write($"\nEnter Grade #{gradeLabel ++}: ");
                num4dl = Convert.ToDecimal(Console.ReadLine());
                lab4 = (lab4 + num4dl);

                Console.Write($"\nEnter Grade #{gradeLabel ++}: ");
                num5dl = Convert.ToDecimal(Console.ReadLine());
                lab5 = (lab5 +num5dl);

                studentSum = (num1dl + num2dl + num3dl + num4dl + num5dl);

                studentGradeArray[x] = (studentSum / 5);






                //Loop if for grade letter assignment----------------------------------------------------------------------------------------->

                if (studentGradeArray[x] >= 101)
                {
                    letterGrade[x] = ("Value exceeded 100...");

                }
                else if (studentGradeArray[x] >= 90)
                {
                    letterGrade[x] = ("A");

                }
                else if (studentGradeArray[x] >= 80)
                {
                    letterGrade[x] = ("B");

                }
                else if (studentGradeArray[x] >= 70)
                {
                    letterGrade[x] = ("C");

                }
                else if (studentGradeArray[x] >= 60)
                {
                    letterGrade[x] = ("D");

                }
                else if (studentGradeArray[x] >= 1)
                {
                    letterGrade[x] = ("F");

                }
                else if (studentGradeArray[x] == 0)
                {
                    letterGrade[x] = ("F");

                }




                Console.WriteLine("------------------------------------------------------------");
                gradeLabel = 1;
                Console.Clear();
            }//closes the first for loop .... 






            for (int i = 0; i < studentName.Length; i++)
            {
                Console.WriteLine($"[Name]: {studentName[i]} \n[Grade]: {studentGradeArray[i]} = {letterGrade[i]} ");
                Console.WriteLine("------------------------------------------------------------");
            }


            lab1Avg = (lab1 / studentHeadCnt);
            lab2Avg = (lab2 / studentHeadCnt);
            lab3Avg = (lab3 / studentHeadCnt);
            lab4Avg = (lab4 / studentHeadCnt);
            lab5Avg = (lab5 / studentHeadCnt);



            //Displays class overall avgerages 
            Console.WriteLine($"\n\nLab #1 Average Score: {lab1Avg}");
            Console.WriteLine($"Lab #2 Average Score: {lab2Avg}");
            Console.WriteLine($"Lab #3 Average Score: {lab3Avg}");
            Console.WriteLine($"Lab #4 Average Score: {lab4Avg}");
            Console.WriteLine($"Lab #5 Average Score: {lab5Avg}");
            //foreach (int z in studentGradeArray)
            //{

            //    Console.Write($"Grade: {z} ");

            //}




            Console.Write("\n\nPress a key to continue...");
            Console.ReadKey();


        }
    }
}

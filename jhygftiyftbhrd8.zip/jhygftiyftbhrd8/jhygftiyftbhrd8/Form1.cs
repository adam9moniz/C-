﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace jhygftiyftbhrd8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        static bool IsTheInputValidInt(String strNum) //ERROR CAATTCHHH
        {
            double num = 0;
            bool blnResult = double.TryParse(strNum, out num);

            return blnResult;

        }

        static bool IsTheInputValidNeg(String strNum) //NEG NUM CHECK
        {
            uint num = 0;
            bool blnResult = uint.TryParse(strNum, out num);

            return blnResult;

        }



        static bool TestRange(double numberToCheck, double bottom, double top)//NUMBER RANGE
        {
            return (numberToCheck >= bottom && numberToCheck <= top);
        }







        private void button1_Click(object sender, EventArgs e)
        {




        
            if(radioButton1.Checked)
            {

                if (textBox1.Text == String.Empty)
                {
                    MessageBox.Show("Please Enter ID");
                    return;
                }
                else
                {

                }

                if (textBox2.Text == String.Empty)
                {
                    MessageBox.Show("Please Enter First Name");
                    return;
                }
                else
                {

                }

                if (textBox3.Text == String.Empty)
                {
                    MessageBox.Show("Please Enter last Name");
                    return;
                }
                else
                {

                }

                if (textBox4.Text == String.Empty)
                {
                    MessageBox.Show("Please Enter GPA");
                    return;
                }
                else
                {
                    
                }


                string status = "Student";
                double id = Convert.ToDouble(textBox1.Text);
                string fname = textBox3.Text;
                string lname = textBox4.Text;
                string major = "";
                double gpa = Convert.ToDouble(textBox4.Text);






                if (radioButton4.Checked)
                {
                    
                     major = "Software Engineering";

                }
                else if (radioButton5.Checked)
                {
                    major = "Network Engineering";

                }
                else if (radioButton6.Checked)
                {
                    major = "Game Development";

                }
                else
                {
                    major = "Not Entered";

                }





                Studentinfo SI = new Studentinfo(id, fname, lname, major, gpa, status);


                SI.ID = id;
                SI.Fname = fname;
                SI.Lname = lname;
                SI.Major = major;
                SI.Gpa = gpa;
                SI.Status = status;


                label5.Text = SI.getnames();



            }
            else if(radioButton2.Checked)
            {
                string status = "Teacher";
                double id = Convert.ToDouble(textBox1.Text);
                string fname = textBox2.Text;
                string lname = textBox3.Text;
                string rank ="";
                string salary = textBox4.Text;

                if (radioButton4.Checked)
                {
                    rank = "Professor";

                }
                else if (radioButton5.Checked)
                {
                    rank = "Assoicate Professor";

                }
                else if(radioButton6.Checked)
                {
                    rank = "Adjunct Teacher";

                }
                else
                {
                    rank = "Not Entered";

                }

                Teacherinfo TI = new Teacherinfo(id, fname, lname, rank, salary, status);


                TI.ID = id;
                TI.Fname = fname;
                TI.Lname = lname;
                TI.Rank = rank;
                TI.Salary = salary;
                TI.Status = status;




                label5.Text = TI.getnames();

            }





            else if (radioButton3.Checked)
            {
                string status = "Admin";
                double id = Convert.ToDouble(textBox1.Text);
                string fname = textBox2.Text;
                string lname = textBox3.Text;
                string department = "";
                double hourlyrate = Convert.ToDouble(textBox4.Text);

                if (radioButton4.Checked)
                {
                    department = "Maintenance";

                }
                else if (radioButton5.Checked)
                {
                    department = "Secuity";

                }
                else if (radioButton6.Checked)
                {
                    department = "Clerical";

                }
                else
                {
                    department = "Not Entered";

                }

                Admininfo AI = new Admininfo(id, fname, lname, department, hourlyrate, status);


                AI.ID = id;
                AI.Fname = fname;
                AI.Lname = lname;
                AI.Department = department;
                AI.Hourlyrate = hourlyrate;
                AI.Status = status;



                label5.Text = AI.getnames();

            }

            //===================================================









        }

























        private void groupBox1_Enter(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                groupBox2.Text = "Major";
                radioButton4.Text = "Software Eng.";
                radioButton5.Text = "Network Eng.";
                radioButton6.Text = "Game Development";
                label4.Text = "GPA";
            }
            else {
                textBox1.Text = String.Empty;
                textBox2.Text = String.Empty;
                textBox3.Text = String.Empty;
                textBox4.Text = String.Empty;
                label6.Text = String.Empty;
                label7.Text = String.Empty;
                label8.Text = String.Empty;
                label9.Text = String.Empty;

            }
             if (radioButton2.Checked)
            {
                groupBox2.Text = "Rank";
                radioButton4.Text = "Professor";
                radioButton5.Text = "Asso. Professor";
                radioButton6.Text = "Adjunct Professor";
                label4.Text = "Salary";
            }
             else
            {
                textBox1.Text = String.Empty;
                textBox2.Text = String.Empty;
                textBox3.Text = String.Empty;
                textBox4.Text = String.Empty;
                label6.Text = String.Empty;
                label7.Text = String.Empty;
                label8.Text = String.Empty;
                label9.Text = String.Empty;
            }
            if(radioButton3.Checked)
            {
                groupBox2.Text = "Department";
                radioButton4.Text = "Maintenance";
                radioButton5.Text = "Security";
                radioButton6.Text = "Clerical";
                label4.Text = "Hourly Rate";

            }
            else
            {
                textBox1.Text = String.Empty;
                textBox2.Text = String.Empty;
                textBox3.Text = String.Empty;
                textBox4.Text = String.Empty;
                label6.Text = String.Empty;
                label7.Text = String.Empty;
                label8.Text = String.Empty;
                label9.Text = String.Empty;
            }



        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                groupBox2.Text = "Major";
                radioButton4.Text = "Software Eng.";
                radioButton5.Text = "Network Eng.";
                radioButton6.Text = "Game Development";
                label4.Text = "GPA";
            }

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                groupBox2.Text = "Rank";
                radioButton4.Text = "Professor";
                radioButton5.Text = "Asso. Professor";
                radioButton6.Text = "Adjunct Professor";
                label4.Text = "Salary";
            }

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                groupBox2.Text = "Department";
                radioButton4.Text = "Maintenance";
                radioButton5.Text = "Security";
                radioButton6.Text = "Clerical";
                label4.Text = "Hourly Rate";

            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            bool result = IsTheInputValidInt(textBox2.Text);

            if (result == true)
            {
                textBox2.Text = String.Empty;
                label7.Text = "*";
                label7.ForeColor = Color.Red;
            }
            else
            {
                label7.Text = " ";

            }

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            bool result = IsTheInputValidInt(textBox3.Text);

            if (result == true)
            {
                textBox3.Text = String.Empty;
                label8.Text = "*";
                label8.ForeColor = Color.Red;
            }
            else
            {
                label8.Text = " ";

            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            bool result = IsTheInputValidInt(textBox1.Text);

            if (result == false)
            {
                textBox1.Text = String.Empty;
                label6.Text = "*";
                label6.ForeColor = Color.Red;
            }
            else
            {
                label6.Text = " ";

            }

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                bool result = IsTheInputValidInt(textBox4.Text);

                if (result == false)
                {
                    textBox4.Text = String.Empty;
                    label9.Text = "*";
                    label9.ForeColor = Color.Red;
                }
                else
                {
                    double dlbnum = Convert.ToDouble(textBox4.Text);
                    bool range = false;



                    range = TestRange(dlbnum, 0.0, 4.0);

                    if (range == false)
                    {
                        textBox4.Text = String.Empty;
                        label9.Text = "*";
                        label9.ForeColor = Color.Red;
                    }
                    else
                    {
                        label9.Text = " ";
                    }
                }

                

                



                

            }
            else if (radioButton2.Checked)
            {
                bool result = IsTheInputValidInt(textBox4.Text);

                if (result == false)
                {
                    textBox4.Text = String.Empty;
                    label9.Text = "*";
                    label9.ForeColor = Color.Red;
                }

            }
            else if (radioButton3.Checked)
            {
                bool result = IsTheInputValidInt(textBox4.Text);

                if (result == false)
                {
                    textBox4.Text = String.Empty;
                    label9.Text = "*";
                    label9.ForeColor = Color.Red;
                }

            }
        }
    }
}

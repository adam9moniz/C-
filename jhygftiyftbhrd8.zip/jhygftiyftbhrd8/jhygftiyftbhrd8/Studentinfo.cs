﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jhygftiyftbhrd8
{
    class Studentinfo : Peoplenames
    {
        private string major;
        private double gpa;
        private string status;

        public Studentinfo(double id, string fname, string lname, string major, double gpa, string status) : base(id, fname, lname)
        {
            this.Major = major;
            this.Gpa = gpa;
            this.Status = status;
        }

        public string Major
        {
            get
            {
                return major;
            }
            set
            {
                major = value;
            }

        }

        public double Gpa
        {
            get
            {
                return gpa;
            }
            set
            {
                gpa = value;
            }

        }

        public string Status
        {
            get
            {
                return status;
            }
            set
            {
                status = value;
            }

        }

        public override string getnames()
        {

            return base.getnames() + $"\nStatus: {status}\n" + $"Major: {major}\nGPA: {gpa}";
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jhygftiyftbhrd8
{
    class Admininfo : Peoplenames
    {
        private string department;
        private double hourlyrate;
        private string status;

        public Admininfo(double id, string fname, string lname, string department, double hourlyrate, string status) : base(id, fname, lname)
        {
            this.Department = department;
            this.Hourlyrate = hourlyrate;
            this.Status = status;
        }

        public string Department
        {
            get
            {
                return department;
            }
            set
            {
                department = value;
            }

        }

        public double Hourlyrate
        {
            get
            {
                return hourlyrate;
            }
            set
            {
                hourlyrate = value;
            }

        }

        public string Status
        {
            get
            {
                return status;
            }
            set
            {
                status = value;
            }

        }
        public override string getnames()
        {
            return base.getnames() + $"\nStatus: {status}\n" + $"Department: {department}\nHourly Rate: ${hourlyrate}";
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jhygftiyftbhrd8
{
    class Peoplenames
    {
        private double id;
        private string fname;
        private string lname;

        public Peoplenames()
        {


        }

        public Peoplenames(double id, string fname, string lname)
        {
            this.ID = id;
            this.Lname = lname;
            this.Fname = fname;

        }


        public double ID
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }

        }

        public string Fname
        {
            get
            {
                return fname;
            }
            set
            {
                fname = value;
            }

        }

        public string Lname
        {
            get
            {
                return lname;
            }
            set
            {
                lname = value;
            }
        }

        public virtual string getnames()
        {
            return ($"ID: {id}\nFirst Name: {fname}\nLast Name: {lname}");

        }


    }
}
